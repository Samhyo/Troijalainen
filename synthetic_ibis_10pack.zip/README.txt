Synthetic IBIS 7.2 model pack (10 files)
------------------------------------------------
These models are generated for parser/search testing.
They are NOT electrically accurate representations of real devices.

Contents: SYN_MODEL_01.ibs ... SYN_MODEL_10.ibs
Each contains: [Component], [Package], [Pin], [Model], Pullup/Pulldown, GND/POWER clamps,
and simple Voltage-Time waveforms.

License: Public Domain (CC0-equivalent intent)
